package com.example.vo;

public class ExampleVO {

}
